/**
 * 
 */
package teaching.hz.pagegrade.data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import teaching.hz.pagegrade.PageGradeException;
import teaching.hz.pagegrade.PageGradeServletContext;

/**
 *
 * @author wiw09-2014
 */
public class PageGrade {

    private static PageGrade instance;
    private String appDir;

    private PageGrade() {
    }

    /**
     * 创建TOTable实例。
     * @return TOTable实例。
     * @throws PageGradeException 
     */
    public static TOTable createTOTable() throws PageGradeException {
        Connection connect;
        try {
            Class.forName(PageGradeServletContext.getInstance().getJdbcDriver());
            connect = DriverManager.getConnection(PageGradeServletContext.getInstance().getDatabaseURL());
            return new TOTable(connect);
        } catch (Exception e) {
            //e.printStackTrace();
            throw new PageGradeException("链接数据文件失败！",e);
        }
    }

   
    /**
     * 创建SOTable实例。
     * @return SOTable实例。
     * @throws PageGradeException 
     */
    public static SOTable createSOTable() throws PageGradeException {
        Connection connect;
        try {
            Class.forName(PageGradeServletContext.getInstance().getJdbcDriver());
            connect = DriverManager.getConnection(PageGradeServletContext.getInstance().getDatabaseURL());
            return new SOTable(connect);
        } catch (Exception e) {
            //e.printStackTrace();
            throw new PageGradeException("链接数据文件失败！",e);
        }
    }  
    
    /**
     * 创建EQTable实例。
     * @return SOTable实例。
     * @throws PageGradeException 
     */
    public static EQTable createEQTable() throws PageGradeException {
        Connection connect;
        try {
            Class.forName(PageGradeServletContext.getInstance().getJdbcDriver());
            connect = DriverManager.getConnection(PageGradeServletContext.getInstance().getDatabaseURL());
            return new EQTable(connect);
        } catch (Exception e) {
            //e.printStackTrace();
            throw new PageGradeException("链接数据文件失败！",e);
        }
    }      
    
/**
     * 创建EPTable实例。
     * @return EPTable实例。
     * @throws PageGradeException 
     */
    public static EPTable createEPTable() throws PageGradeException {
        Connection connect;
        try {
            Class.forName(PageGradeServletContext.getInstance().getJdbcDriver());
            connect = DriverManager.getConnection(PageGradeServletContext.getInstance().getDatabaseURL());
            return new EPTable(connect);
        } catch (Exception e) {
            //e.printStackTrace();
            throw new PageGradeException("链接数据文件失败！",e);
        }
    }  
    
    /**
     * 创建PageGrade实例。
     *
     * @return PageGrade实例
     */
    public static PageGrade createInstance() {
        if (instance == null) {
            instance = new PageGrade();
        }
        return instance;
    }
    
   /**
     * 设置ClassRoom数据库存放根目录。数据库文件ClassRoom.db3存放在该目录下的
     * data目录中，即<>\data\PageGrade.db3。
     *
     * @param dir - 数据库存放根目录
     */
    public void setAppDir(String dir) {
        appDir = dir;
    }

}
