/*
 *  ID    VARCHAR (32) PRIMARY KEY NOT NULL,
    Name  VARCHAR (32) DEFAULT (''),
    Nox   VARCHAR (16) DEFAULT (''),
    File  VARCHAR (64) DEFAULT (''),
    Grade VARCHAR (32) DEFAULT ('') 
 */
package teaching.hz.pagegrade.data;

/**
 *
 * @author wiw07
 */
public class SO {
    protected String ID ;
    protected String Name ;
    protected String Nox;
    protected String Filename;
    protected String Grade;
    protected String Suggest;
    
    public SO(){
    }

    public SO(String ID, String Name, String Nox, String Filename, String Grade) {
        this.ID = ID;
        this.Name = Name;
        this.Nox = Nox;
        this.Filename = Filename;
        this.Grade = Grade;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getNox() {
        return Nox;
    }

    public void setNox(String Nox) {
        this.Nox = Nox;
    }

    public String getFilename() {
        return Filename;
    }

    public void setFilename(String Filename) {
        this.Filename = Filename;
    }

    public String getGrade() {
        return Grade;
    }

    public void setGrade(String Grade) {
        this.Grade = Grade;
    }

    public String getSuggest() {
        return Suggest;
    }

    public void setSuggest(String Suggest) {
        this.Suggest = Suggest;
    } 
}
