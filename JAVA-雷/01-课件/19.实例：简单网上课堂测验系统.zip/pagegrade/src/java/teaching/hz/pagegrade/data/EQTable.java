/*
 *
 */
package teaching.hz.pagegrade.data;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import teaching.hz.pagegrade.PageGradeException;

/**
 *
 * @author wiw09-2014
 */
public class EQTable extends PageGradeTable {

    public EQTable(Connection connect) {
        super(connect, "EQ_试题库模板");
    }

    public ArrayList<EQ> getAll() throws PageGradeException {
        ArrayList<EQ> exams;
        Statement stm;
        ResultSet rs;
        String sql;
        EQ eq;

        String number;
        String question;
        String answer;

        exams = new ArrayList();
        try {
            sql = "SELECT * FROM " + TableName;
            stm = connect.createStatement();
            rs = stm.executeQuery(sql);
            while (rs.next()) {
                number = rs.getString(1);
                question = rs.getString(2);
                answer = rs.getString(3);
                eq = new EQ(number, question, answer);
                exams.add(eq);
            }
            rs.close();
            stm.close();
        } catch (SQLException e) {
            //e.printStackTrace();
            throw new PageGradeException("没有课堂测验试题！",e);
        }   
        return exams;
    }
     
    public void insert(EQ question) throws PageGradeException{
        Statement stm;
        String sql;       
        try {
            sql = "INSERT INTO " + TableName + " ("; 
            sql = sql + "QCode, "; 
            sql = sql + "Question, "; 
            sql = sql + "Answer ";                       
            sql = sql + ") VALUES (";
            sql = sql + " \'" + question.getQCode() + "\',";
            sql = sql + " \'" + question.getQuestion() + "\',";
            sql = sql + " \'" + question.getAnswer() + "\' ";
            sql = sql + ")";   
            
            stm = connect.createStatement();     
            stm.executeUpdate(sql);
            stm.close();
        } catch (SQLException e) {
            //e.printStackTrace();
            throw new PageGradeException("添加测验题目（EQ）出错！",e);
        }                   
    }
   
    /**
     * 
     * @throws PageGradeException 
     */
    public void removeall() throws PageGradeException{
        Statement stm;
        String sql;      
        try {
            sql = "DELETE FROM " + TableName + ";"; 
            stm = connect.createStatement();     
            stm.executeUpdate(sql);
            stm.close();           
        } catch (SQLException e) {
            //e.printStackTrace();
            throw new PageGradeException("清除测验题目（EQ）出错！",e);
        }                  
    } 
    
    /**
     * 
     * @param number
     * @throws PageGradeException 
     */
    public void remove(String number) throws PageGradeException {
        Statement stm;
        String sql;
        try {
            sql = "DELETE FROM " + TableName + " WHERE QCode=\'" + number + "\'";      
            stm = connect.createStatement();     
            stm.executeUpdate(sql);
            stm.close();
        } catch (SQLException e) {
            //e.printStackTrace();
            throw new PageGradeException("删除测验题目（EQ）出错！",e);
        }                 
    }     

}
