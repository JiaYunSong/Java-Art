/*
 */
package teaching.hz.pagegrade;

/**
 *
 * @author wiw09-2014
 */
public class PageGradeException extends Exception{

    public PageGradeException(String message) {
        super(message);
    }

    public PageGradeException(String message, Throwable cause) {
        super(message, cause);
    }
      
}
