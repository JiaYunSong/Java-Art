package teaching.hz.pagegrade;

/**
 *
 * @author gege
 */
public class TOBean {
    
}
