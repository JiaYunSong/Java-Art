/**
 */
package teaching.hz.pagegrade.data;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import teaching.hz.pagegrade.PageGradeException;

/**
 *
 * @author wiw07
 */
public class TOTable extends PageGradeTable {

    public TOTable(Connection connect) {
        super(connect, "TO");
    }

    public ArrayList<TO> select() throws PageGradeException {
        ArrayList<TO> tos;
        Statement st;
        ResultSet rs;

        if (connect != null) {
            try {
                st = connect.createStatement();
                rs = st.executeQuery("SELECT * FROM " + "\"" + TableName + "\";");
                tos = new ArrayList();
                while (rs.next()) {
                    TO to = new TO();
                    to.setID(rs.getString(1));
                    to.setName(rs.getString(2));
                    to.setNo1(rs.getString(3));
                    to.setNo2(rs.getString(4));
                    to.setNo3(rs.getString(5));
                    to.setNo4(rs.getString(6));
                    to.setNo5(rs.getString(7));
                    to.setNo6(rs.getString(8));
                    to.setNo7(rs.getString(9));
                    to.setNo8(rs.getString(10));
                    to.setNo9(rs.getString(11));
                    to.setNo10(rs.getString(12));
                    to.setNo11(rs.getString(13));
                    to.setNo12(rs.getString(14));
                    to.setNo13(rs.getString(15));
                    to.setNo14(rs.getString(16));
                    to.setNo15(rs.getString(17));
                    to.setNo16(rs.getString(18));
                    to.setNo17(rs.getString(19));
                    to.setNo18(rs.getString(20));
                    to.setNo19(rs.getString(21));
                    to.setNo20(rs.getString(22));
                    to.setNo21(rs.getString(23));
                    to.setNo22(rs.getString(24));
                    to.setNo23(rs.getString(25));
                    to.setNo24(rs.getString(26));
                    to.setNo25(rs.getString(27));
                    to.setNo26(rs.getString(28));
                    to.setNo27(rs.getString(29));
                    to.setNo28(rs.getString(30));
                    to.setNo29(rs.getString(31));
                    to.setNo30(rs.getString(32));
                    to.setPassword(rs.getString(33));

                    tos.add(to);
                }
                return tos;
            } catch (SQLException e) {
                throw new PageGradeException("TO表操作失败！", e);
            }
        }
        return null;
    }

    public TO find(String id) throws PageGradeException {
        String sql;
        Statement st;
        ResultSet rs;
        if (connect != null) {
            try {
                st = connect.createStatement();
                sql = "SELECT * FROM " + "\"" + TableName + "\" ";
                sql = sql + "WHERE id=\'" + id + "\';";
                rs = st.executeQuery(sql);
                if (rs.next()) {
                    TO to = new TO();
                    to.setID(rs.getString(1));
                    to.setName(rs.getString(2));
                    to.setNo1(rs.getString(3));
                    to.setNo2(rs.getString(4));
                    to.setNo3(rs.getString(5));
                    to.setNo4(rs.getString(6));
                    to.setNo5(rs.getString(7));
                    to.setNo6(rs.getString(8));
                    to.setNo7(rs.getString(9));
                    to.setNo8(rs.getString(10));
                    to.setNo9(rs.getString(11));
                    to.setNo10(rs.getString(12));
                    to.setNo11(rs.getString(13));
                    to.setNo12(rs.getString(14));
                    to.setNo13(rs.getString(15));
                    to.setNo14(rs.getString(16));
                    to.setNo15(rs.getString(17));
                    to.setNo16(rs.getString(18));
                    to.setNo17(rs.getString(19));
                    to.setNo18(rs.getString(20));
                    to.setNo19(rs.getString(21));
                    to.setNo20(rs.getString(22));
                    to.setNo21(rs.getString(23));
                    to.setNo22(rs.getString(24));
                    to.setNo23(rs.getString(25));
                    to.setNo24(rs.getString(26));
                    to.setNo25(rs.getString(27));
                    to.setNo26(rs.getString(28));
                    to.setNo27(rs.getString(29));
                    to.setNo28(rs.getString(30));
                    to.setNo29(rs.getString(31));
                    to.setNo30(rs.getString(32));
                    to.setPassword(rs.getString(33));
                    return to;
                }
            } catch (SQLException e) {
                throw new PageGradeException("TO表操作失败！", e);
            }
        }
        return null;
    }
    
    public void updateNox(String id, String nox, String value) throws PageGradeException {
        String sql;
        Statement st;
        if (connect != null) {
            try {
                st = connect.createStatement();
                sql = "UPDATE " + "\"" + TableName + "\" ";
                sql = sql + " SET " + nox + "=\'" + value + "\' ";
                sql = sql + " WHERE id=\'" + id + "\';";    
                st.executeUpdate(sql);
            } catch (SQLException e) {
                throw new PageGradeException("TO表数据修改操作失败！", e);
            }
        }  
    }
    

}
