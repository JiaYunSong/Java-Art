/*
 */
package teaching.hz.pagegrade.data;

import java.sql.Connection;
import java.sql.SQLException;
import teaching.hz.pagegrade.*;

/**
 *
 * @author wiw09-2014
 */
public class PageGradeTable {
    protected String TableName;
    protected Connection connect;
    
    public PageGradeTable(){
    }
    
    public PageGradeTable(Connection connect, String tableName){
        this.connect = connect;
        this.TableName = tableName;
    }

    public void close() throws PageGradeException {
        try {
            this.connect.close();
        } catch (SQLException e) {
            throw new PageGradeException("关闭数据库出错！",e); 
        }
    }
    
}
