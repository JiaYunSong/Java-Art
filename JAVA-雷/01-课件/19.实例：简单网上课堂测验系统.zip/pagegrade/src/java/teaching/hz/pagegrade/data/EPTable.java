/*
 */
package teaching.hz.pagegrade.data;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import teaching.hz.pagegrade.PageGradeException;
import teaching.hz.pagegrade.data.PageGradeTable;

/**
 *
 * @author wiw09-2014
 */
public class EPTable extends PageGradeTable {

    public EPTable(Connection connect) {
        super(connect, "EP_试卷模板");
    }
    
    /**
     * 
     * @param exampage
     * @throws PageGradeException 
     */
    public void insert(EP exampage) throws PageGradeException{
        Statement stm;
        String sql;       
        try {
            sql = "INSERT INTO "+ this.TableName +" ("; 
            sql = sql + "EDate, "; 
            sql = sql + "ID, "; 
            sql = sql + "QCode, "; 
            sql = sql + "Question, "; 
            sql = sql + "Answer "; 
            sql = sql + ") VALUES (";
            sql = sql + " \'" + exampage.getEdate() + "\',";
            sql = sql + " \'" + exampage.getId() + "\',";            
            sql = sql + " \'" + exampage.getQCode() + "\',";
            sql = sql + " \'" + exampage.getQuestion() + "\',";
            sql = sql + " \'" + exampage.getAnswer() + "\'";                     
            sql = sql + ")";            
            stm = connect.createStatement();     
            stm.executeUpdate(sql);
            stm.close();
        } catch (SQLException e) {
            //e.printStackTrace();
            throw new PageGradeException("添加EP数据到数据库出错！",e);
        }                   
    }
    /**
     * 
     * @param stud_id
     * @return
     * @throws PageGradeException 
     */
    public ArrayList<EP> select(String stud_id) throws PageGradeException{
        ArrayList<EP> eps;
        Statement stm;
        ResultSet rs;
        String sql;
        EP ep;
        eps = new ArrayList();
        try {
            sql = "SELECT * FROM "+ this.TableName +" WHERE ID=\'" + stud_id + "\'"; 
            stm = connect.createStatement();     
            rs = stm.executeQuery(sql);
            while(rs.next()){
                ep = new EP(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5));
                eps.add(ep);
            }
            rs.close();
            stm.close();
        } catch (SQLException e) {
            //e.printStackTrace();
            throw new PageGradeException("在ET表选择符合指定ID的数据出错！",e);
        }            
        return eps;
    }


    
}
