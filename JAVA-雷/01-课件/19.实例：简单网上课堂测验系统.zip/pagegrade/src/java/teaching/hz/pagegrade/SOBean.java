/**
 *
 */
package teaching.hz.pagegrade;

import java.util.ArrayList;
import teaching.hz.pagegrade.data.PageGrade;
import teaching.hz.pagegrade.data.SO;
import teaching.hz.pagegrade.data.SOTable;
import teaching.hz.pagegrade.data.TO;
import teaching.hz.pagegrade.data.TOTable;

/**
 *
 * @author gege
 */
public class SOBean {
    /**
     * 用户登录状态标记
     */
    private boolean isLogin = false;
    /**
     * 用户姓名
     */
    private String name;
    /**
     * 用户登录ID
     */
    private String id;
    /**
     * 用户登录密码
     */
    private String password;

    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public boolean isIsLogin() {
        return isLogin;
    }
    public void setIsLogin(boolean isLogin) {
        this.isLogin = isLogin;
    }
    /**
     * 测试用户id和password是否正确。
     *
     * @return　true- false-
     * @throws PageGradeException
     */
    public boolean login() throws PageGradeException {
        TOTable toTable;
        TO to;
        
        toTable = PageGrade.createTOTable();
        to = toTable.find(id);
        toTable.close();
        if (to != null && password != null) {
            if(to.getPassword().compareTo(this.password)==0){
                this.name = to.getName();
                this.isLogin = true;
                return true;
            }
        }
        return false;
    }
    /**
     * 返回用户ID为id的所有SO记录。
     * @return
     * @throws PageGradeException 
     */
    public ArrayList<SO> getStud() throws PageGradeException{
        ArrayList<SO> sos;
        SOTable soTable;
        soTable = PageGrade.createSOTable();
        sos = soTable.select(id);
        soTable.close();   
        return sos;
    }

}
