/*
 */
package teaching.hz.pagegrade.data;

/**
 *
 * @author wiw09-2014
 */
public class EQ {
    //CREATE TABLE EQ_试题库模板 (QCode CHAR (32) PRIMARY KEY UNIQUE NOT NULL, Question TEXT DEFAULT (''), Answer TEXT DEFAULT (''));
    protected String qcode;
    protected String question;
    protected String answer;

    public EQ() {
    }

    public EQ(String qcode, String question, String answer) {
        this.qcode = qcode;
        this.question = question;
        this.answer = answer;
    }

    public String getQCode() {
        return qcode;
    }

    public void setQCode(String number) {
        this.qcode = number;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }
        
}
