package teaching.hz.pagegrade;

import java.io.File;
import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import teaching.hz.pagegrade.data.*;

/**
 * Web application lifecycle listener.
 *
 * @author wiw09-2014
 */
public class PageGradeServletContext implements ServletContextListener {

    private static PageGradeServletContext instance;
    private ServletContext servletContext;
    private String appRoot;
    private String copyright;
    private String jdbcDriver;
    private String databaseURL;
    private PageGrade pageGrade;

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        instance = this;
        servletContext = sce.getServletContext();
        appRoot = servletContext.getRealPath("/");
        pageGrade = PageGrade.createInstance();
        pageGrade.setAppDir(appRoot);

    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
    }

    public static PageGradeServletContext getInstance() {
        return instance;
    }

    public String getCopyright() {
        copyright = servletContext.getInitParameter("Copyright");
        return copyright;
    }

    public void setCopyright(String copyright) {
        this.copyright = copyright;
    }

    public String getAppRoot() {
        return appRoot;
    }

    public String getJdbcDriver() {
        jdbcDriver = servletContext.getInitParameter("SQLiteJDBCDriver");
        return jdbcDriver;
    }

    public void setJdbcDriver(String jdbcDriver) {
        this.jdbcDriver = jdbcDriver;
    }

    /**
     * 返回SQLite数据库连接URL
     *
     * @return SQLite数据库连接URL
     */
    public String getDatabaseURL() {
        String realPath;
        String databaseName;
        realPath = servletContext.getRealPath("/data");
        databaseName = servletContext.getInitParameter("DataBaseName");
        databaseURL = "jdbc:sqlite:" + realPath + File.separator + databaseName;
        return databaseURL;
    }

    public void setDatabaseURL(String databaseURL) {
        this.databaseURL = databaseURL;
    }

}
