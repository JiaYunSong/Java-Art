/**
 *
 *  CREATE TABLE "TO" (ID VARCHAR (32) PRIMARY KEY NOT NULL, Name VARCHAR (32) DEFAULT (''),
 * No1 VARCHAR (64) DEFAULT (''), No2 VARCHAR (64) DEFAULT (''), No3 VARCHAR (64) DEFAULT (''), No4 VARCHAR (64) DEFAULT (''), No5 VARCHAR (64) DEFAULT (''),
 * No6 VARCHAR (64) DEFAULT (''), No7 VARCHAR (64) DEFAULT (''), No8 VARCHAR (64) DEFAULT (''), No9 VARCHAR (64) DEFAULT (''), No10 VARCHAR (64) DEFAULT (''),
 * No11 VARCHAR (64) DEFAULT (''), No12 VARCHAR (64) DEFAULT (''), No13 VARCHAR (64) DEFAULT (''), No14 VARCHAR (64) DEFAULT (''), No15 VARCHAR (64) DEFAULT (''),
 * No16 VARCHAR (64) DEFAULT (''), No17 VARCHAR (64) DEFAULT (''), No18 VARCHAR (64) DEFAULT (''), No19 VARCHAR (64) DEFAULT (''), No20 VARCHAR (64) DEFAULT (''),
 * No21 VARCHAR (64) DEFAULT (''), No22 VARCHAR (64) DEFAULT (''), No23 VARCHAR (64) DEFAULT (''), No24 VARCHAR (64) DEFAULT (''), No25 VARCHAR (64) DEFAULT (''),
 * No26 VARCHAR (64) DEFAULT (''), No27 VARCHAR (64) DEFAULT (''), No28 VARCHAR (64) DEFAULT (''), No29 VARCHAR (64) DEFAULT (''), No30 VARCHAR (64) DEFAULT (''),
 * password VARCHAR (32) DEFAULT (''));
 */
package teaching.hz.pagegrade.data;

/**
 *
 * @author gege
 */
public class TO {

    protected String ID ;
    protected String Name ;
    protected String No1 ;
    protected String No2 ;
    protected String No3 ;
    protected String No4 ;
    protected String No5 ;
    protected String No6 ;
    protected String No7 ;
    protected String No8 ;
    protected String No9 ;
    protected String No10 ;
    protected String No11 ;
    protected String No12 ;
    protected String No13 ;
    protected String No14 ;
    protected String No15 ;
    protected String No16 ;
    protected String No17 ;
    protected String No18 ;
    protected String No19 ;
    protected String No20 ;
    protected String No21 ;
    protected String No22 ;
    protected String No23 ;
    protected String No24 ;
    protected String No25 ;
    protected String No26 ;
    protected String No27 ;
    protected String No28 ;
    protected String No29 ;
    protected String No30 ;
    protected String password ;

    public TO() {
    }

    public TO(String ID, String Name) {
        this.ID = ID;
        this.Name = Name;
    }

    public TO(String ID, String Name, String password) {
        this(ID, Name);
        this.password = password;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getNo1() {
        return No1;
    }

    public void setNo1(String No1) {
        this.No1 = No1;
    }

    public String getNo2() {
        return No2;
    }

    public void setNo2(String No2) {
        this.No2 = No2;
    }

    public String getNo3() {
        return No3;
    }

    public void setNo3(String No3) {
        this.No3 = No3;
    }

    public String getNo4() {
        return No4;
    }

    public void setNo4(String No4) {
        this.No4 = No4;
    }

    public String getNo5() {
        return No5;
    }

    public void setNo5(String No5) {
        this.No5 = No5;
    }

    public String getNo6() {
        return No6;
    }

    public void setNo6(String No6) {
        this.No6 = No6;
    }

    public String getNo7() {
        return No7;
    }

    public void setNo7(String No7) {
        this.No7 = No7;
    }

    public String getNo8() {
        return No8;
    }

    public void setNo8(String No8) {
        this.No8 = No8;
    }

    public String getNo9() {
        return No9;
    }

    public void setNo9(String No9) {
        this.No9 = No9;
    }

    public String getNo10() {
        return No10;
    }

    public void setNo10(String No10) {
        this.No10 = No10;
    }

    public String getNo11() {
        return No11;
    }

    public void setNo11(String No11) {
        this.No11 = No11;
    }

    public String getNo12() {
        return No12;
    }

    public void setNo12(String No12) {
        this.No12 = No12;
    }

    public String getNo13() {
        return No13;
    }

    public void setNo13(String No13) {
        this.No13 = No13;
    }

    public String getNo14() {
        return No14;
    }

    public void setNo14(String No14) {
        this.No14 = No14;
    }

    public String getNo15() {
        return No15;
    }

    public void setNo15(String No15) {
        this.No15 = No15;
    }

    public String getNo16() {
        return No16;
    }

    public void setNo16(String No16) {
        this.No16 = No16;
    }

    public String getNo17() {
        return No17;
    }

    public void setNo17(String No17) {
        this.No17 = No17;
    }

    public String getNo18() {
        return No18;
    }

    public void setNo18(String No18) {
        this.No18 = No18;
    }

    public String getNo19() {
        return No19;
    }

    public void setNo19(String No19) {
        this.No19 = No19;
    }

    public String getNo20() {
        return No20;
    }

    public void setNo20(String No20) {
        this.No20 = No20;
    }

    public String getNo21() {
        return No21;
    }

    public void setNo21(String No21) {
        this.No21 = No21;
    }

    public String getNo22() {
        return No22;
    }

    public void setNo22(String No22) {
        this.No22 = No22;
    }

    public String getNo23() {
        return No23;
    }

    public void setNo23(String No23) {
        this.No23 = No23;
    }

    public String getNo24() {
        return No24;
    }

    public void setNo24(String No24) {
        this.No24 = No24;
    }

    public String getNo25() {
        return No25;
    }

    public void setNo25(String No25) {
        this.No25 = No25;
    }

    public String getNo26() {
        return No26;
    }

    public void setNo26(String No26) {
        this.No26 = No26;
    }

    public String getNo27() {
        return No27;
    }

    public void setNo27(String No27) {
        this.No27 = No27;
    }

    public String getNo28() {
        return No28;
    }

    public void setNo28(String No28) {
        this.No28 = No28;
    }

    public String getNo29() {
        return No29;
    }

    public void setNo29(String No29) {
        this.No29 = No29;
    }

    public String getNo30() {
        return No30;
    }

    public void setNo30(String No30) {
        this.No30 = No30;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    

}
