/**
 *
 */
package teaching.hz.pagegrade;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadBase.FileSizeLimitExceededException;
import org.apache.commons.fileupload.FileUploadBase.SizeLimitExceededException;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import teaching.hz.pagegrade.data.PageGrade;
import teaching.hz.pagegrade.data.SO;
import teaching.hz.pagegrade.data.SOTable;

/**
 *
 * @author wiw09-2014
 */
public class FileUpLoadServlet extends HttpServlet {

    private static final int MAX_FILE_SIZE = 1024 * 1024 * 20;
    private static final int MAX_REQUEST_SIZE = 1024 * 1024 * 50;
    private static final String SAVE_DIR = "/upload";
    private static final String FILE_TYPE = ".zip";

    private String savePath;    //上传文件的存放目录
    private String filename;    //上传文件的名称

    private String id;          //学号
    private String name;        //学生姓名
    private String nox;         //次数

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String message = "上传文件出错 ";
        boolean success = false;    //文件上传完成标志
        PrintWriter out;

        out = response.getWriter();
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");

        //上传文件的存放目录的路径
        savePath = this.getServletContext().getRealPath(SAVE_DIR);

        // 创建文件上传核心类  
        DiskFileItemFactory factory = new DiskFileItemFactory();
        ServletFileUpload sfu = new ServletFileUpload(factory);

        //设置编码  
        sfu.setHeaderEncoding("UTF-8");
        //解析上传请求
        List<FileItem> itemList;
        try {
            itemList = sfu.parseRequest(request);
            for (FileItem fileItem : itemList) {
                if (fileItem.isFormField()) {
                    //处理普通表单域处理
                    if (fileItem.getFieldName().equals("id")) {
                        id = fileItem.getString();
                    }
                    if (fileItem.getFieldName().equals("name")) {
                        name = fileItem.getString("UTF-8");
                    }
                    if (fileItem.getFieldName().equals("nox")) {
                        nox = "No" + fileItem.getString();
                    }
                } else {
                    //处理上传文件
                    // 获得文件大小  
                    long size = fileItem.getSize();
                    if (size <= MAX_FILE_SIZE) {
                        //组合文件名前缀
                        filename = nox + "_" + id +"_";
                        // 获得包含路径的文件名 
                        String source = fileItem.getName();
                        //检查文件类型
                        if(source.lastIndexOf(FILE_TYPE)==-1){
                            success = false;
                            message += "文件类型不符合要求";
                            break;
                        }
                        // 分离出文件名
                        int pos = source.lastIndexOf(File.separator);
                        if (pos != -1 && (pos + 1) < source.length()) {
                            filename += source.substring(pos + 1);
                        } else {
                            filename += source;
                        }
                        //将文件保存到指定的路径  
                        File file = new File(savePath, filename);
                        fileItem.write(file);
                        //上传成功
                        success = true;
                    } else {
                        message += "文件太大";
                    }
                    break;
                }
            }
        } catch (SizeLimitExceededException e) {
            e.printStackTrace();
        } catch (FileSizeLimitExceededException e) {
            e.printStackTrace();
            //request.setAttribute("msg", "文件太大");
        } catch (FileUploadException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

        //上传完毕保存上传者信息到SO 
        if (success) {
            try {
                //添加上传记录到SO表
                SOTable soTable;
                SO so;
                soTable = PageGrade.createSOTable();
                so = new SO(id, name, nox, filename, "");
                soTable.addSO(so);
                soTable.close();
                request.getRequestDispatcher("sologin.jsp").forward(request, response);
            } catch (PageGradeException e) {
                e.printStackTrace();
            }
        } else {
            out.print(message);
            //request.getRequestDispatcher("errorpage.jsp").forward(request, response);
        }

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
