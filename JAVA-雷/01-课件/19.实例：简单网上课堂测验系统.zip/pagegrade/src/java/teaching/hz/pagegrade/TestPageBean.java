package teaching.hz.pagegrade;

import java.util.ArrayList;
import teaching.hz.pagegrade.data.EQ;
import teaching.hz.pagegrade.data.EQTable;
import teaching.hz.pagegrade.data.PageGrade;

/**
 *
 * @author wiw09-2014
 */
public class TestPageBean {
    private ArrayList<EQ> exams;

    /**
     * 从试题EQ装入当前考试试题。
     * @throws PageGradeException 
     */
    public void load() throws PageGradeException {
        EQTable examTable;
        examTable = PageGrade.createEQTable();
        exams = examTable.getAll();

    }
    /**
     * 返回所有试题。
     * @return 
     */
    public ArrayList<EQ> getExamQuestions() {
        return exams;
    }

}
