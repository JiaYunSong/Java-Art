package teaching.hz.pagegrade.data;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import teaching.hz.pagegrade.PageGradeException;

/**
 *
 * @author wiw07
 */
public class SOTable extends PageGradeTable {
    
    public SOTable(Connection connect){
        super(connect, "SO");
    } 
    /**
     * 选择符合指定id的所有记录。
     * @param id - 用户id。
     * @return
     * @throws PageGradeException 
     */
    public ArrayList<SO> select(String id)throws PageGradeException{
        ArrayList<SO> sos;
        String sql;
        Statement st;
        ResultSet rs;
        SO so;
        if (connect != null) {
            try {
                sos = new ArrayList();
                st = connect.createStatement();
                sql = "SELECT * FROM " + "\"" + TableName + "\" ";
                sql = sql + "WHERE id=\'" + id + "\';";
                rs = st.executeQuery(sql);
                while (rs.next()) {
                    so = new SO();
                    so.setID(rs.getString(1));
                    so.setName(rs.getString(2));
                    so.setNox(rs.getString(3));
                    so.setFilename(rs.getString(4));
                    so.setGrade(rs.getString(5));
                    sos.add(so);
                }
                return sos;
            } catch (SQLException e) {
                throw new PageGradeException("SO表选择数据操作失败！", e);
            }
        }  
        return null;
    }
    
    public void addSO(SO so)throws PageGradeException{
        Statement stm;
        String sql;
        
        try{
            sql = "INSERT INTO " + "\"" + TableName + "\"  ";
            sql = sql + "(ID, Name, Nox, File, Grade) VALUES(";
            sql = sql + "\'" + so.getID() + "\',";
            sql = sql + "\'" + so.getName() + "\',";
            sql = sql + "\'" + so.getNox() + "\',";
            sql = sql + "\'" + so.getFilename() + "\',";
            sql = sql + "\'" + so.getGrade() + "\'";
            sql = sql + ");";
            stm = connect.createStatement();
            stm.executeUpdate(sql);
            
        }catch(SQLException e){
            throw new PageGradeException("SO表插入新数据操作失败！", e);
        }    
         
        
    }
        
}
