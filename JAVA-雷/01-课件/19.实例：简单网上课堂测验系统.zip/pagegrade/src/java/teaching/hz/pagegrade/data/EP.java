/*
 */
package teaching.hz.pagegrade.data;;

/**
 *
 * @author wiw09-2014
 */
public class EP extends EQ{
    //CREATE TABLE EP_试卷模板 (EDate CHAR (48) DEFAULT (''), ID CHAR (32) DEFAULT (''), 
    //QCode CHAR (32) DEFAULT (''), Question TEXT DEFAULT (''), Answer TEXT DEFAULT (''), AGrade TEXT DEFAULT (''));
    protected String edate;
    protected String id;
    protected String agrade;

    public EP(String edate, String id, String qcode, String question, String answer) {
        super(qcode, question, answer);
        this.edate = edate;
        this.id = id;
    }

    public EP(String edate, String id, String agrade, String qcode, String question, String answer) {
        super(qcode, question, answer);
        this.edate = edate;
        this.id = id;
        this.agrade = agrade;
    }

    public String getEdate() {
        return edate;
    }

    public void setEdate(String edate) {
        this.edate = edate;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAgrade() {
        return agrade;
    }

    public void setAgrade(String agrade) {
        this.agrade = agrade;
    }
    
      
}
